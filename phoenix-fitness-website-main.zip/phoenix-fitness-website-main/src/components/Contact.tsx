import { motion } from "framer-motion";
import { MapPin, Phone, Clock, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const Contact = () => (
  <section id="contact" className="py-20">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <p className="text-primary font-display tracking-[0.3em] text-sm mb-2">GET IN TOUCH</p>
        <h2 className="text-4xl md:text-5xl font-bold">
          Contact <span className="text-gradient-yellow">Us</span>
        </h2>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-10">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <div className="space-y-6 mb-8">
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <MapPin className="text-primary" size={20} />
              </div>
              <div>
                <h4 className="font-display font-semibold text-foreground mb-1">Address</h4>
                <p className="text-sm text-muted-foreground">Prakash Nagar Bhutaiyatand, Vikash Bhawan Road, near S. M Palace, Lanka, Ghazipur, Uttar Pradesh 233001</p>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Phone className="text-primary" size={20} />
              </div>
              <div>
                <h4 className="font-display font-semibold text-foreground mb-1">Phone</h4>
                <a href="tel:08081326940" className="text-sm text-muted-foreground hover:text-primary transition-colors">08081326940</a>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Clock className="text-primary" size={20} />
              </div>
              <div>
                <h4 className="font-display font-semibold text-foreground mb-1">Hours</h4>
                <p className="text-sm text-muted-foreground">Monday – Saturday: 5:00 AM – 10:00 PM</p>
                <p className="text-sm text-muted-foreground">Sunday: 6:00 AM – 12:00 PM</p>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <Button variant="hero" size="lg" asChild>
              <a href="tel:08081326940" className="gap-2">
                <Phone size={16} />
                Call Now
              </a>
            </Button>
            <Button variant="whatsapp" size="lg" asChild>
              <a
                href="https://wa.me/918081326940?text=Hi%20Phoenix%20Fitness!%20I%20want%20to%20know%20more."
                target="_blank"
                rel="noopener noreferrer"
                className="gap-2"
              >
                <MessageCircle size={16} />
                WhatsApp Us
              </a>
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl overflow-hidden h-[400px]"
        >
          <iframe
            title="Phoenix Fitness Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3600.0!2d83.58!3d25.58!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjXCsDM0JzQ4LjAiTiA4M8KwMzQnNDguMCJF!5e0!3m2!1sen!2sin!4v1234567890"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </div>
  </section>
);

export default Contact;
