import { motion } from "framer-motion";
import { Dumbbell, Users, Clock, Award } from "lucide-react";
import heroGym from "@/assets/hero-gym.jpg";

const stats = [
  { icon: Dumbbell, value: "100+", label: "Equipment" },
  { icon: Users, value: "500+", label: "Members" },
  { icon: Clock, value: "18hrs", label: "Open Daily" },
  { icon: Award, value: "4.8★", label: "Rating" },
];

const About = () => (
  <section id="about" className="py-20">
    <div className="container mx-auto px-6">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <img src={heroGym} alt="Phoenix Fitness interior" className="rounded-2xl w-full object-cover aspect-[4/3]" />
          <div className="absolute -bottom-6 -right-6 w-32 h-32 rounded-2xl bg-primary flex items-center justify-center">
            <div className="text-center">
              <p className="text-3xl font-display font-bold text-primary-foreground">5+</p>
              <p className="text-xs font-semibold text-primary-foreground/80">Years</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <p className="text-primary font-display tracking-[0.3em] text-sm mb-2">ABOUT US</p>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Welcome To <span className="text-gradient-yellow">Phoenix Fitness</span>
          </h2>
          <p className="text-muted-foreground mb-4 leading-relaxed">
            Located in the heart of Ghazipur, Uttar Pradesh, Phoenix Fitness is your premier destination for achieving your fitness goals. We offer an exclusive range of state-of-the-art equipment, expert trainers, and a motivating environment.
          </p>
          <p className="text-muted-foreground mb-8 leading-relaxed">
            Whether you're a beginner or a seasoned athlete, our facility at Prakash Nagar Bhutaiyatand, near S. M Palace, Lanka, has everything you need to transform your body and mind.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center p-4 rounded-xl bg-secondary">
                <stat.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                <p className="text-2xl font-display font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default About;
