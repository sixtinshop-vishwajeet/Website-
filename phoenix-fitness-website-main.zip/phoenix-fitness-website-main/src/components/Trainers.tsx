import { motion } from "framer-motion";
import { Instagram } from "lucide-react";
import trainer1 from "@/assets/trainer1.jpg";
import trainer2 from "@/assets/trainer2.jpg";
import trainer3 from "@/assets/trainer3.jpg";

const trainers = [
  { name: "Rahul Sharma", role: "Strength Coach", image: trainer1 },
  { name: "Priya Singh", role: "Cardio & HIIT", image: trainer2 },
  { name: "Vikram Yadav", role: "CrossFit Trainer", image: trainer3 },
];

const Trainers = () => (
  <section id="trainers" className="py-20">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <p className="text-primary font-display tracking-[0.3em] text-sm mb-2">OUR TEAM</p>
        <h2 className="text-4xl md:text-5xl font-bold">
          Expert <span className="text-gradient-yellow">Trainers</span>
        </h2>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
        {trainers.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className="group relative rounded-2xl overflow-hidden"
          >
            <img src={t.image} alt={t.name} className="w-full aspect-[3/4] object-cover transition-transform duration-500 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-lg font-display font-bold text-foreground">{t.name}</h3>
              <p className="text-primary text-sm font-medium">{t.role}</p>
            </div>
            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <Instagram size={18} className="text-primary-foreground" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Trainers;
