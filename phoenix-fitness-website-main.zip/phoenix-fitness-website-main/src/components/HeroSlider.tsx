import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroGym from "@/assets/hero-gym.jpg";
import heroTrainer from "@/assets/hero-trainer.jpg";
import heroCardio from "@/assets/hero-cardio.jpg";

const slides = [
  {
    image: heroGym,
    title: "An Exclusive Range Of",
    highlight: "Fitness Equipment",
    subtitle: "Train with the best machines at Phoenix Fitness, Ghazipur",
  },
  {
    image: heroTrainer,
    title: "Transform Your Body With",
    highlight: "Expert Trainers",
    subtitle: "Professional guidance to reach your fitness goals",
  },
  {
    image: heroCardio,
    title: "Unleash Your Potential In",
    highlight: "Cardio Zone",
    subtitle: "State-of-the-art cardio equipment for peak performance",
  },
];

const HeroSlider = () => {
  const [current, setCurrent] = useState(0);

  const next = useCallback(() => setCurrent((p) => (p + 1) % slides.length), []);
  const prev = useCallback(() => setCurrent((p) => (p - 1 + slides.length) % slides.length), []);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <section id="home" className="relative h-screen w-full overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7 }}
          className="absolute inset-0"
        >
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${slides[current].image})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/40" />
          {/* Yellow circle glow on the left */}
          <div className="absolute -left-32 top-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-primary/10 blur-3xl" />
        </motion.div>
      </AnimatePresence>

      <div className="relative z-10 container mx-auto h-full flex items-center px-6">
        <motion.div
          key={current}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="max-w-2xl"
        >
          <p className="text-primary font-display text-lg tracking-[0.3em] mb-4">PHOENIX FITNESS</p>
          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-2">
            {slides[current].title}
          </h1>
          <h1 className="text-5xl md:text-7xl font-bold text-gradient-yellow leading-tight mb-6">
            {slides[current].highlight}
          </h1>
          <p className="text-muted-foreground text-lg mb-8 max-w-lg">{slides[current].subtitle}</p>
          <div className="flex gap-4">
            <Button variant="hero" size="lg" asChild>
              <a href="#membership">Join Now</a>
            </Button>
            <Button variant="heroOutline" size="lg" asChild>
              <a href="#contact">Book Trial</a>
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Slider controls */}
      <button
        onClick={prev}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-secondary/80 flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={next}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-secondary/80 flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
      >
        <ChevronRight size={24} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-3">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`w-3 h-3 rounded-full transition-all ${
              i === current ? "bg-primary w-8" : "bg-muted-foreground/50"
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroSlider;
