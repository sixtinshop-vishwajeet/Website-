import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const plans = [
  {
    name: "Basic",
    price: "999",
    period: "/month",
    features: ["Access to gym floor", "Basic equipment", "Locker access", "5 AM – 10 PM access"],
    popular: false,
  },
  {
    name: "Pro",
    price: "1,999",
    period: "/month",
    features: ["All Basic features", "Personal trainer (2x/week)", "Diet consultation", "All equipment access", "Steam & sauna"],
    popular: true,
  },
  {
    name: "Elite",
    price: "3,499",
    period: "/month",
    features: ["All Pro features", "Unlimited personal training", "Nutrition planning", "Priority booking", "Guest passes (2/month)"],
    popular: false,
  },
];

const Membership = () => (
  <section id="membership" className="py-20 bg-surface-dark">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <p className="text-primary font-display tracking-[0.3em] text-sm mb-2">PRICING</p>
        <h2 className="text-4xl md:text-5xl font-bold">
          Membership <span className="text-gradient-yellow">Plans</span>
        </h2>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {plans.map((plan, i) => (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className={`relative rounded-2xl p-8 ${
              plan.popular
                ? "bg-primary text-primary-foreground border-2 border-primary"
                : "bg-card border border-border"
            }`}
          >
            {plan.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-foreground text-background text-xs font-display font-bold px-4 py-1 rounded-full uppercase tracking-wider">
                Most Popular
              </span>
            )}
            <h3 className="text-xl font-display font-bold mb-1">{plan.name}</h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-4xl font-display font-bold">₹{plan.price}</span>
              <span className={`text-sm ${plan.popular ? "text-primary-foreground/70" : "text-muted-foreground"}`}>{plan.period}</span>
            </div>
            <ul className="space-y-3 mb-8">
              {plan.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm">
                  <Check size={16} className={plan.popular ? "text-primary-foreground" : "text-primary"} />
                  {f}
                </li>
              ))}
            </ul>
            <Button
              variant={plan.popular ? "heroOutline" : "hero"}
              className={`w-full ${plan.popular ? "border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" : ""}`}
            >
              Join Now
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Membership;
