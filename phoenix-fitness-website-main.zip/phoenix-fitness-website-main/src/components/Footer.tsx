import { Phone, MapPin, Instagram, Facebook, Youtube } from "lucide-react";

const Footer = () => (
  <footer className="bg-surface-dark border-t border-border py-12">
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-4 gap-8 mb-10">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-2xl font-display font-bold text-primary">PHOENIX</span>
            <span className="text-2xl font-display font-bold text-foreground">FITNESS</span>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Your premium fitness destination in Ghazipur. Transform your body, transform your life.
          </p>
        </div>

        <div>
          <h4 className="font-display font-semibold text-foreground mb-4">Quick Links</h4>
          <ul className="space-y-2">
            {["Home", "About", "Membership", "Trainers", "Equipment", "Contact"].map((link) => (
              <li key={link}>
                <a href={`#${link.toLowerCase()}`} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  {link}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display font-semibold text-foreground mb-4">Contact Info</h4>
          <div className="space-y-3">
            <div className="flex gap-2 items-start">
              <MapPin size={16} className="text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">Prakash Nagar, Vikash Bhawan Road, Ghazipur, UP 233001</p>
            </div>
            <div className="flex gap-2 items-center">
              <Phone size={16} className="text-primary flex-shrink-0" />
              <a href="tel:08081326940" className="text-sm text-muted-foreground hover:text-primary transition-colors">08081326940</a>
            </div>
          </div>
        </div>

        <div>
          <h4 className="font-display font-semibold text-foreground mb-4">Follow Us</h4>
          <div className="flex gap-3">
            {[Instagram, Facebook, Youtube].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Icon size={18} />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-border pt-6 text-center">
        <p className="text-sm text-muted-foreground">© 2026 Phoenix Fitness. All Rights Reserved.</p>
      </div>
    </div>
  </footer>
);

export default Footer;
