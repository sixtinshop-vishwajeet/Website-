import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const reviews = [
  { name: "Amit Kumar", text: "Best gym in Ghazipur! Amazing equipment and supportive trainers. Highly recommended.", rating: 5 },
  { name: "Sneha Gupta", text: "Phoenix Fitness transformed my fitness journey. The environment is motivating and the trainers are very professional.", rating: 5 },
  { name: "Raj Patel", text: "Great variety of equipment. Clean facility and friendly staff. Worth every rupee!", rating: 5 },
  { name: "Pooja Verma", text: "Love the cardio section! The trainers create personalized plans that actually work.", rating: 4 },
];

const Reviews = () => (
  <section className="py-20 bg-surface-dark">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <p className="text-primary font-display tracking-[0.3em] text-sm mb-2">TESTIMONIALS</p>
        <h2 className="text-4xl md:text-5xl font-bold">
          What Members <span className="text-gradient-yellow">Say</span>
        </h2>
        <p className="text-muted-foreground mt-3">4.8 ★ from 37 reviews</p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reviews.map((r, i) => (
          <motion.div
            key={r.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-2xl p-6 border border-border"
          >
            <Quote size={24} className="text-primary mb-4" />
            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{r.text}</p>
            <div className="flex gap-1 mb-2">
              {Array.from({ length: r.rating }).map((_, j) => (
                <Star key={j} size={14} className="fill-primary text-primary" />
              ))}
            </div>
            <p className="font-display font-semibold text-foreground text-sm">{r.name}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Reviews;
