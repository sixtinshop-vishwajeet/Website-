import { motion } from "framer-motion";
import catStrength from "@/assets/cat-strength.jpg";
import catCardio from "@/assets/cat-cardio.jpg";
import catFreeweights from "@/assets/cat-freeweights.jpg";
import catBenches from "@/assets/cat-benches.jpg";
import catAccessories from "@/assets/cat-accessories.jpg";

const categories = [
  { name: "Strength Machines", image: catStrength },
  { name: "Cardio Equipment", image: catCardio },
  { name: "Free Weights", image: catFreeweights },
  { name: "Benches", image: catBenches },
  { name: "Accessories", image: catAccessories },
];

const EquipmentCategories = () => (
  <section id="equipment" className="py-20 bg-surface-dark">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <p className="text-primary font-display tracking-[0.3em] text-sm mb-2">OUR EQUIPMENT</p>
        <h2 className="text-4xl md:text-5xl font-bold">
          Equipment <span className="text-gradient-yellow">Categories</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="group relative rounded-xl overflow-hidden aspect-square cursor-pointer"
          >
            <img src={cat.image} alt={cat.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
            <div className="absolute inset-0 bg-primary/0 group-hover:bg-primary/10 transition-colors duration-300" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-sm md:text-base font-display font-semibold text-foreground">{cat.name}</h3>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default EquipmentCategories;
