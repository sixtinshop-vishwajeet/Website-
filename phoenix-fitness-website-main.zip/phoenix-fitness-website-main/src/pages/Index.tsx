import Navbar from "@/components/Navbar";
import HeroSlider from "@/components/HeroSlider";
import EquipmentCategories from "@/components/EquipmentCategories";
import About from "@/components/About";
import Membership from "@/components/Membership";
import Trainers from "@/components/Trainers";
import Reviews from "@/components/Reviews";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Index = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <HeroSlider />
    <EquipmentCategories />
    <About />
    <Membership />
    <Trainers />
    <Reviews />
    <Contact />
    <Footer />
    <WhatsAppButton />
  </div>
);

export default Index;
