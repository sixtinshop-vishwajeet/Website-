import { Outlet, Link, useLocation } from "react-router";
import { Button } from "../components/ui/button";
import { Menu, X, Phone, Mail, MapPin } from "lucide-react";
import { useState } from "react";

export function PublicLayout() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { path: "/", label: "Home" },
    { path: "/menu", label: "Menu" },
    { path: "/reservations", label: "Reservations" },
    { path: "/contact", label: "Contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xl font-bold">LB</span>
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text text-transparent">
                La Bella Vista
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`transition-colors ${
                    location.pathname === link.path
                      ? "text-orange-600 font-semibold"
                      : "text-neutral-600 hover:text-orange-500"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link to="/admin">
                <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                  Admin
                </Button>
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-neutral-600"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="md:hidden py-4 border-t">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`block py-2 transition-colors ${
                    location.pathname === link.path
                      ? "text-orange-600 font-semibold"
                      : "text-neutral-600"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <Link to="/admin" onClick={() => setMobileMenuOpen(false)}>
                <Button className="bg-orange-600 hover:bg-orange-700 text-white mt-4 w-full">
                  Admin
                </Button>
              </Link>
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-neutral-900 text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 text-orange-500">La Bella Vista</h3>
              <p className="text-neutral-400">
                Experience fine dining at its best with our carefully curated menu.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4 text-orange-500">Contact</h3>
              <div className="space-y-2 text-neutral-400">
                <div className="flex items-center gap-2">
                  <Phone size={16} />
                  <span>+1 (555) 987-6543</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={16} />
                  <span>info@labellavista.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={16} />
                  <span>123 Culinary Avenue, New York</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4 text-orange-500">Hours</h3>
              <div className="space-y-1 text-neutral-400">
                <p>Tuesday - Thursday: 5:00 PM - 10:00 PM</p>
                <p>Friday: 5:00 PM - 11:00 PM</p>
                <p>Saturday: 12:00 PM - 11:00 PM</p>
                <p>Sunday: 12:00 PM - 9:00 PM</p>
                <p>Monday: Closed</p>
              </div>
            </div>
          </div>
          <div className="border-t border-neutral-800 mt-8 pt-8 text-center text-neutral-400">
            <p>&copy; 2026 La Bella Vista. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
