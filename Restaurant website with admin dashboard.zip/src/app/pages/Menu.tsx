import { useState } from "react";
import { useRestaurantStore } from "../store/restaurantStore";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

export function Menu() {
  const menuItems = useRestaurantStore((state) => state.menuItems);
  const [selectedCategory, setSelectedCategory] = useState("All");

  const categories = ["All", ...new Set(menuItems.map((item) => item.category))];
  const filteredItems =
    selectedCategory === "All"
      ? menuItems
      : menuItems.filter((item) => item.category === selectedCategory);

  return (
    <div className="min-h-screen bg-neutral-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4">
            Our <span className="text-orange-600">Menu</span>
          </h1>
          <p className="text-xl text-neutral-600">
            Discover our exquisite selection of culinary delights
          </p>
        </div>

        {/* Category Tabs */}
        <Tabs defaultValue="All" className="mb-8">
          <TabsList className="flex flex-wrap justify-center gap-2 bg-transparent h-auto p-0">
            {categories.map((category) => (
              <TabsTrigger
                key={category}
                value={category}
                onClick={() => setSelectedCategory(category)}
                className="data-[state=active]:bg-orange-600 data-[state=active]:text-white bg-white border border-orange-200"
              >
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <Card
              key={item.id}
              className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <div className="relative h-64">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
                {!item.available && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <Badge variant="destructive" className="text-lg px-4 py-2">
                      Unavailable
                    </Badge>
                  </div>
                )}
              </div>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-2xl font-bold">{item.name}</h3>
                  <span className="text-orange-600 font-bold text-xl">
                    ${item.price.toFixed(2)}
                  </span>
                </div>
                <p className="text-neutral-600 mb-4">{item.description}</p>
                <Badge className="bg-orange-100 text-orange-600 hover:bg-orange-200">
                  {item.category}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-neutral-600 text-xl">No items found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
