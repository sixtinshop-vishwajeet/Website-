import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { ChefHat, Clock, Award, Heart } from "lucide-react";
import { useRestaurantStore } from "../store/restaurantStore";

export function Home() {
  const menuItems = useRestaurantStore((state) => state.menuItems);
  const featuredItems = menuItems.filter(item => item.available).slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1769773297747-bd00e31b33aa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwcmVzdGF1cmFudCUyMGRpbmluZ3xlbnwxfHx8fDE3NzMxNjI0Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Restaurant dining"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50" />
        </div>
        <div className="relative z-10 text-center text-white container mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            Welcome to <span className="text-orange-500">La Bella Vista</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-neutral-200">
            Where Every Meal is a Masterpiece
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/menu">
              <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-white px-8">
                View Menu
              </Button>
            </Link>
            <Link to="/reservations">
              <Button size="lg" variant="outline" className="bg-white text-orange-600 border-white hover:bg-neutral-100 px-8">
                Make Reservation
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">
            Why Choose <span className="text-orange-600">Us</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <Card className="text-center border-orange-100 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ChefHat className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Expert Chefs</h3>
                <p className="text-neutral-600">
                  Our world-class chefs bring decades of culinary expertise
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-orange-100 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Award Winning</h3>
                <p className="text-neutral-600">
                  Recognized for excellence in fine dining
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-orange-100 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Fresh Ingredients</h3>
                <p className="text-neutral-600">
                  Only the finest, locally sourced ingredients
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-orange-100 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Timely Service</h3>
                <p className="text-neutral-600">
                  Exceptional service from start to finish
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="py-20 bg-neutral-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-4">
            Featured <span className="text-orange-600">Dishes</span>
          </h2>
          <p className="text-center text-neutral-600 mb-12">
            Discover our chef's special selections
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredItems.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-xl transition-shadow">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-64 object-cover"
                />
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold">{item.name}</h3>
                    <span className="text-orange-600 font-bold text-lg">
                      ${item.price.toFixed(2)}
                    </span>
                  </div>
                  <p className="text-neutral-600 mb-4">{item.description}</p>
                  <span className="inline-block bg-orange-100 text-orange-600 px-3 py-1 rounded-full text-sm">
                    {item.category}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/menu">
              <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                View Full Menu
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">
                Our <span className="text-orange-600">Story</span>
              </h2>
              <p className="text-neutral-600 mb-4">
                Since our establishment, La Bella Vista has been committed to providing an
                unforgettable dining experience. Our passion for culinary excellence and
                dedication to quality have made us a beloved destination for food enthusiasts.
              </p>
              <p className="text-neutral-600 mb-6">
                Every dish we serve is crafted with care, using only the finest ingredients
                sourced from local farms and trusted suppliers. Our team of expert chefs
                combines traditional techniques with innovative approaches to create
                dishes that delight all senses.
              </p>
              <Link to="/contact">
                <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                  Learn More
                </Button>
              </Link>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
              <img
                src="https://images.unsplash.com/photo-1769867863357-790b6150e3b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBhbWJpYW5jZXxlbnwxfHx8fDE3NzMyNDE4MzF8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Restaurant interior"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600 to-orange-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Experience Excellence?</h2>
          <p className="text-xl mb-8">Book your table now and join us for an unforgettable meal</p>
          <Link to="/reservations">
            <Button size="lg" className="bg-white text-orange-600 hover:bg-neutral-100 px-8">
              Reserve Your Table
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
