import { useState } from "react";
import { useRestaurantStore } from "../../store/restaurantStore";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { toast } from "sonner";

export function AdminSettings() {
  const { restaurantInfo, updateRestaurantInfo } = useRestaurantStore();
  const [generalInfo, setGeneralInfo] = useState({
    name: restaurantInfo.name,
    description: restaurantInfo.description,
    address: restaurantInfo.address,
    phone: restaurantInfo.phone,
    email: restaurantInfo.email,
  });

  const [hours, setHours] = useState(restaurantInfo.hours);

  const handleGeneralSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateRestaurantInfo(generalInfo);
    toast.success("General information updated successfully");
  };

  const handleHoursSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateRestaurantInfo({ hours });
    toast.success("Operating hours updated successfully");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-neutral-600">Manage restaurant information and configuration</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general">General Information</TabsTrigger>
          <TabsTrigger value="hours">Operating Hours</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
        </TabsList>

        {/* General Information */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Restaurant Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGeneralSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Restaurant Name</Label>
                  <Input
                    id="name"
                    value={generalInfo.name}
                    onChange={(e) =>
                      setGeneralInfo({ ...generalInfo, name: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={generalInfo.description}
                    onChange={(e) =>
                      setGeneralInfo({ ...generalInfo, description: e.target.value })
                    }
                    rows={4}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={generalInfo.address}
                    onChange={(e) =>
                      setGeneralInfo({ ...generalInfo, address: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={generalInfo.phone}
                      onChange={(e) =>
                        setGeneralInfo({ ...generalInfo, phone: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={generalInfo.email}
                      onChange={(e) =>
                        setGeneralInfo({ ...generalInfo, email: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="bg-orange-600 hover:bg-orange-700 text-white"
                >
                  Save Changes
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Operating Hours */}
        <TabsContent value="hours">
          <Card>
            <CardHeader>
              <CardTitle>Operating Hours</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleHoursSubmit} className="space-y-4">
                {Object.entries(hours).map(([day, time]) => (
                  <div key={day} className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                    <Label htmlFor={day} className="capitalize font-semibold">
                      {day}
                    </Label>
                    <Input
                      id={day}
                      value={time}
                      onChange={(e) =>
                        setHours({ ...hours, [day]: e.target.value })
                      }
                      placeholder="e.g., 5:00 PM - 10:00 PM or Closed"
                      required
                    />
                  </div>
                ))}

                <Button
                  type="submit"
                  className="bg-orange-600 hover:bg-orange-700 text-white mt-6"
                >
                  Save Hours
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Theme & Appearance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <Label className="mb-2 block">Current Theme</Label>
                  <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg border-2 border-orange-500">
                    <div className="flex gap-2">
                      <div className="w-8 h-8 rounded-full bg-orange-500"></div>
                      <div className="w-8 h-8 rounded-full bg-orange-600"></div>
                      <div className="w-8 h-8 rounded-full bg-orange-700"></div>
                    </div>
                    <div>
                      <p className="font-semibold">Premium Orange Theme</p>
                      <p className="text-sm text-neutral-600">Active</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Brand Colors</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="w-full h-20 rounded-lg bg-orange-500 mb-2"></div>
                      <p className="text-sm font-medium">Primary</p>
                      <p className="text-xs text-neutral-500">#F97316</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full h-20 rounded-lg bg-orange-600 mb-2"></div>
                      <p className="text-sm font-medium">Secondary</p>
                      <p className="text-xs text-neutral-500">#EA580C</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full h-20 rounded-lg bg-neutral-900 mb-2"></div>
                      <p className="text-sm font-medium">Dark</p>
                      <p className="text-xs text-neutral-500">#171717</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full h-20 rounded-lg bg-white border-2 mb-2"></div>
                      <p className="text-sm font-medium">Light</p>
                      <p className="text-xs text-neutral-500">#FFFFFF</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <p className="text-sm text-neutral-600">
                    The premium orange theme is currently applied across your website.
                    This creates a warm, inviting atmosphere perfect for a restaurant.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
