import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { useRestaurantStore } from "../../store/restaurantStore";
import {
  DollarSign,
  Users,
  UtensilsCrossed,
  Calendar,
  TrendingUp,
  Clock,
} from "lucide-react";
import { Badge } from "../../components/ui/badge";

export function AdminDashboard() {
  const menuItems = useRestaurantStore((state) => state.menuItems);
  const reservations = useRestaurantStore((state) => state.reservations);

  const stats = {
    totalRevenue: menuItems.reduce((sum, item) => sum + item.price, 0) * 45.2, // Mock calculation
    totalReservations: reservations.length,
    totalMenuItems: menuItems.length,
    activeReservations: reservations.filter((r) => r.status === "confirmed").length,
  };

  const recentReservations = reservations
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-700";
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-neutral-100 text-neutral-700";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-neutral-600">Welcome to La Bella Vista Admin Panel</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm">Total Revenue</p>
                <h3 className="text-3xl font-bold mt-2">
                  ${stats.totalRevenue.toFixed(2)}
                </h3>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm">+12.5% from last month</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <DollarSign className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm">Total Reservations</p>
                <h3 className="text-3xl font-bold mt-2">{stats.totalReservations}</h3>
                <p className="text-sm text-neutral-500 mt-2">All time bookings</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm">Menu Items</p>
                <h3 className="text-3xl font-bold mt-2">{stats.totalMenuItems}</h3>
                <p className="text-sm text-neutral-500 mt-2">Active dishes</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <UtensilsCrossed className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm">Confirmed Today</p>
                <h3 className="text-3xl font-bold mt-2">{stats.activeReservations}</h3>
                <p className="text-sm text-neutral-500 mt-2">Active bookings</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Reservations */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-orange-600" />
              Recent Reservations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentReservations.map((reservation) => (
                <div
                  key={reservation.id}
                  className="flex items-center justify-between p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold">{reservation.name}</h4>
                      <Badge className={getStatusColor(reservation.status)}>
                        {reservation.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-neutral-600">
                      {new Date(reservation.date).toLocaleDateString()} at {reservation.time}
                    </p>
                    <p className="text-sm text-neutral-500">
                      {reservation.guests} {reservation.guests === 1 ? "guest" : "guests"}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-neutral-500">
                      {new Date(reservation.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
              {recentReservations.length === 0 && (
                <div className="text-center py-8 text-neutral-500">
                  No reservations yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Popular Menu Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UtensilsCrossed className="w-5 h-5 text-orange-600" />
              Popular Menu Items
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {menuItems.slice(0, 5).map((item) => (
                <div
                  key={item.id}
                  className="flex items-center gap-4 p-4 bg-neutral-50 rounded-lg hover:bg-neutral-100 transition-colors"
                >
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold">{item.name}</h4>
                    <p className="text-sm text-neutral-600">{item.category}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-orange-600">${item.price.toFixed(2)}</p>
                    <Badge
                      variant={item.available ? "default" : "secondary"}
                      className={item.available ? "bg-green-100 text-green-700" : ""}
                    >
                      {item.available ? "Available" : "Unavailable"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Restaurant is currently open</h3>
              <p className="text-neutral-600">Operating hours: 5:00 PM - 10:00 PM</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
