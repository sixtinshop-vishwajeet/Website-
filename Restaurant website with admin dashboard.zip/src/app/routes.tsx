import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { Menu } from "./pages/Menu";
import { Reservations } from "./pages/Reservations";
import { Contact } from "./pages/Contact";
import { AdminLayout } from "./pages/admin/AdminLayout";
import { AdminDashboard } from "./pages/admin/AdminDashboard";
import { AdminMenu } from "./pages/admin/AdminMenu";
import { AdminReservations } from "./pages/admin/AdminReservations";
import { AdminSettings } from "./pages/admin/AdminSettings";
import { NotFound } from "./pages/NotFound";
import { PublicLayout } from "./pages/PublicLayout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: PublicLayout,
    children: [
      { index: true, Component: Home },
      { path: "menu", Component: Menu },
      { path: "reservations", Component: Reservations },
      { path: "contact", Component: Contact },
    ],
  },
  {
    path: "/admin",
    Component: AdminLayout,
    children: [
      { index: true, Component: AdminDashboard },
      { path: "menu", Component: AdminMenu },
      { path: "reservations", Component: AdminReservations },
      { path: "settings", Component: AdminSettings },
    ],
  },
  {
    path: "*",
    Component: NotFound,
  },
]);
