import { create } from "zustand";

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  available: boolean;
}

export interface Reservation {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  status: "pending" | "confirmed" | "cancelled";
  notes?: string;
  createdAt: string;
}

export interface RestaurantInfo {
  name: string;
  description: string;
  address: string;
  phone: string;
  email: string;
  hours: {
    monday: string;
    tuesday: string;
    wednesday: string;
    thursday: string;
    friday: string;
    saturday: string;
    sunday: string;
  };
}

interface RestaurantStore {
  menuItems: MenuItem[];
  reservations: Reservation[];
  restaurantInfo: RestaurantInfo;
  addMenuItem: (item: Omit<MenuItem, "id">) => void;
  updateMenuItem: (id: string, item: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  addReservation: (reservation: Omit<Reservation, "id" | "createdAt">) => void;
  updateReservation: (id: string, reservation: Partial<Reservation>) => void;
  deleteReservation: (id: string) => void;
  updateRestaurantInfo: (info: Partial<RestaurantInfo>) => void;
}

const initialMenuItems: MenuItem[] = [
  {
    id: "1",
    name: "Grilled Salmon",
    description: "Fresh Atlantic salmon with lemon butter sauce, served with seasonal vegetables",
    price: 28.99,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1485921325833-c519f76c4927",
    available: true,
  },
  {
    id: "2",
    name: "Beef Tenderloin",
    description: "Premium beef tenderloin with truffle mashed potatoes and red wine reduction",
    price: 42.99,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1546833998-877b37c2e5c6",
    available: true,
  },
  {
    id: "3",
    name: "Caesar Salad",
    description: "Classic Caesar with crispy romaine, parmesan, and house-made dressing",
    price: 12.99,
    category: "Appetizer",
    image: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9",
    available: true,
  },
  {
    id: "4",
    name: "Lobster Bisque",
    description: "Rich and creamy lobster soup with a touch of cognac",
    price: 16.99,
    category: "Appetizer",
    image: "https://images.unsplash.com/photo-1547592166-23ac45744acd",
    available: true,
  },
  {
    id: "5",
    name: "Chocolate Lava Cake",
    description: "Warm chocolate cake with molten center, served with vanilla ice cream",
    price: 10.99,
    category: "Dessert",
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c",
    available: true,
  },
  {
    id: "6",
    name: "Tiramisu",
    description: "Classic Italian dessert with espresso-soaked ladyfingers and mascarpone",
    price: 9.99,
    category: "Dessert",
    image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9",
    available: true,
  },
  {
    id: "7",
    name: "Mushroom Risotto",
    description: "Creamy arborio rice with wild mushrooms and parmesan",
    price: 24.99,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1476124369491-c2a5f53a5c53",
    available: true,
  },
  {
    id: "8",
    name: "Margherita Pizza",
    description: "Wood-fired pizza with fresh mozzarella, basil, and San Marzano tomatoes",
    price: 18.99,
    category: "Main Course",
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002",
    available: true,
  },
];

const initialReservations: Reservation[] = [
  {
    id: "1",
    name: "John Smith",
    email: "john.smith@email.com",
    phone: "+1 (555) 123-4567",
    date: "2026-03-15",
    time: "19:00",
    guests: 4,
    status: "confirmed",
    notes: "Window seat preferred",
    createdAt: "2026-03-10T10:30:00Z",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah.j@email.com",
    phone: "+1 (555) 234-5678",
    date: "2026-03-14",
    time: "20:00",
    guests: 2,
    status: "pending",
    notes: "Anniversary dinner",
    createdAt: "2026-03-11T14:20:00Z",
  },
  {
    id: "3",
    name: "Michael Brown",
    email: "mbrown@email.com",
    phone: "+1 (555) 345-6789",
    date: "2026-03-16",
    time: "18:30",
    guests: 6,
    status: "confirmed",
    createdAt: "2026-03-09T09:15:00Z",
  },
];

const initialRestaurantInfo: RestaurantInfo = {
  name: "La Bella Vista",
  description: "Experience fine dining at its best with our carefully curated menu featuring the finest ingredients and exceptional service.",
  address: "123 Culinary Avenue, Gourmet District, New York, NY 10001",
  phone: "+1 (555) 987-6543",
  email: "info@labellavista.com",
  hours: {
    monday: "Closed",
    tuesday: "5:00 PM - 10:00 PM",
    wednesday: "5:00 PM - 10:00 PM",
    thursday: "5:00 PM - 10:00 PM",
    friday: "5:00 PM - 11:00 PM",
    saturday: "12:00 PM - 11:00 PM",
    sunday: "12:00 PM - 9:00 PM",
  },
};

export const useRestaurantStore = create<RestaurantStore>((set) => ({
  menuItems: initialMenuItems,
  reservations: initialReservations,
  restaurantInfo: initialRestaurantInfo,

  addMenuItem: (item) =>
    set((state) => ({
      menuItems: [
        ...state.menuItems,
        { ...item, id: Date.now().toString() },
      ],
    })),

  updateMenuItem: (id, item) =>
    set((state) => ({
      menuItems: state.menuItems.map((m) =>
        m.id === id ? { ...m, ...item } : m
      ),
    })),

  deleteMenuItem: (id) =>
    set((state) => ({
      menuItems: state.menuItems.filter((m) => m.id !== id),
    })),

  addReservation: (reservation) =>
    set((state) => ({
      reservations: [
        ...state.reservations,
        {
          ...reservation,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
        },
      ],
    })),

  updateReservation: (id, reservation) =>
    set((state) => ({
      reservations: state.reservations.map((r) =>
        r.id === id ? { ...r, ...reservation } : r
      ),
    })),

  deleteReservation: (id) =>
    set((state) => ({
      reservations: state.reservations.filter((r) => r.id !== id),
    })),

  updateRestaurantInfo: (info) =>
    set((state) => ({
      restaurantInfo: { ...state.restaurantInfo, ...info },
    })),
}));
