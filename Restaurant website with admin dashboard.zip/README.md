
  # Restaurant website with admin dashboard

  This is a code bundle for Restaurant website with admin dashboard. The original project is available at https://www.figma.com/design/Amhku6Hs25JMnqeTPqdveU/Restaurant-website-with-admin-dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  